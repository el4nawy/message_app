import React from 'react';



const friend = () => {

    return 
        <div></div>;
    
};
export default friend;