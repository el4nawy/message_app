import React from 'react';

import style from "./NavBar.module.css";

const NavBar = () => {

    return 
        <div></div>;
    
};
export default NavBar;