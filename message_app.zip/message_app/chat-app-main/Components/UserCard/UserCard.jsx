import React from 'react';



const UserCard = () => {

    return 
        <div></div>;
    
};
export default UserCard;