import React from 'react';



const Model = () => {

    return 
        <div></div>;
    
};
export default Model;